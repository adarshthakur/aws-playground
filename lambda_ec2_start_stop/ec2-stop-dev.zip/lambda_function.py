import boto3

def lambda_handler(event, context):
    ec2_client = boto3.client('ec2')

    # Access specific fields or process the message data
    environment_tag_value = event.get('environment')
    # Describe instances with a filter for the 'environment' tag with value 'Dev'
    instances = ec2_client.describe_instances(
        Filters=[
            {'Name': 'tag:environment', 'Values': [environment_tag_value]}
        ]
    )
    print(instances)
    instance_ids_to_stop = []
    for reservation in instances['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            instance_ids_to_stop.append(instance_id)
            if instance['State']['Name'] == 'running':
              instance_ids_to_stop.append(instance_id)            

    if instance_ids_to_stop:
        # Stop instances found with the specified tag criteria
        ec2_client.stop_instances(InstanceIds=instance_ids_to_stop)
        return {
            'statusCode': 200,
            'body': 'EC2 instances with environment=Dev tag are stopped.'
        }
    else:
        return {
            'statusCode': 404,
            'body': 'No EC2 instances found with environment=Dev tag.'
        }
